#arduino upload script for Justin's computer... Might work for yours as well
./arduino-cli upload 7SegDisplay/7SegDisplay.ino -b arduino:avr:leonardo -p /dev/ttyACM0

